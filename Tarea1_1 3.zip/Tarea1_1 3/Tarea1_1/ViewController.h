//
//  ViewController.h
//  Tarea1_1
//
//  Created by SDA on 4/11/13.
//  Copyright (c) 2013 SDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtUsername;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;

@end
