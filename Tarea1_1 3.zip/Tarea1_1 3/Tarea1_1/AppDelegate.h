//
//  AppDelegate.h
//  Tarea1_1
//
//  Created by SDA on 4/11/13.
//  Copyright (c) 2013 SDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
